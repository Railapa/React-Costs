import { FaFacebook, FaInstagram, FaLinkedin } from 'react-icons/fa'
import styles from './Footer.module.css'

export const Footer = () => {
    return(
        <footer className={styles.footer}>
            <ul className={styles.socialList}>
                <li><FaFacebook/></li>
                <li><FaInstagram/></li>
                <li><FaLinkedin/></li>
            </ul>
            <p className={styles.copyRight}><span>Costs</span> &copy; 2026</p>
        </footer>
    )
}